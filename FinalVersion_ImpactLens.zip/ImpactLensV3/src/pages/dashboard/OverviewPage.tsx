import { motion } from 'framer-motion';
import { FileText, Layers, TrendingUp, Users } from 'lucide-react';
import { DashboardHeader } from '@/components/layout/DashboardHeader';
import { useAppStore } from '@/lib/store';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['#0ea5e9', '#14b8a6', '#f59e0b', '#8b5cf6'];

export default function OverviewPage() {
  const { members, analysisResults } = useAppStore();
  
  const latestResult = analysisResults[0];
  const hasData = members.length > 0;

  const bandData = hasData ? [
    { name: 'High Impact', value: members.filter(m => m.band === 'High Impact').length },
    { name: 'Moderate', value: members.filter(m => m.band === 'Moderate Impact').length },
    { name: 'Growing', value: members.filter(m => m.band === 'Growing').length },
    { name: 'New', value: members.filter(m => m.band === 'New').length },
  ].filter(d => d.value > 0) : [];

  const contributionData = hasData ? members.slice(0, 5).map(m => ({
    name: m.name.split(' ')[0],
    reviews: m.contributions?.codeReviews || 0,
    mentoring: m.contributions?.mentoringHours || 0,
    projects: m.contributions?.projectsLed || 0,
  })) : [];

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Dashboard" />
      
      <div className="p-6">
        {!hasData ? (
          <EmptyState />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Stats Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard
                icon={Users}
                label="Team Members"
                value={members.length}
                trend={null}
              />
              <StatCard
                icon={TrendingUp}
                label="Avg Impact Score"
                value={latestResult?.metrics.avgImpactScore || '—'}
                trend={latestResult ? '+12%' : null}
              />
              <StatCard
                icon={Layers}
                label="Team Health"
                value={latestResult?.metrics.teamHealth ? `${latestResult.metrics.teamHealth}%` : '—'}
                trend={null}
              />
              <StatCard
                icon={FileText}
                label="Analyses Run"
                value={analysisResults.length}
                trend={null}
              />
            </div>

            {/* Charts */}
            <div className="grid lg:grid-cols-2 gap-6">
              {/* Band Distribution */}
              <div className="stat-card">
                <h3 className="text-lg font-semibold mb-4">Impact Band Distribution</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={bandData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={4}
                        dataKey="value"
                        label={({ name, value }) => `${name}: ${value}`}
                      >
                        {bandData.map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Contributions */}
              <div className="stat-card">
                <h3 className="text-lg font-semibold mb-4">Contribution Breakdown</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={contributionData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="name" tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                      <YAxis tick={{ fontSize: 12 }} stroke="hsl(var(--muted-foreground))" />
                      <Tooltip 
                        contentStyle={{ 
                          backgroundColor: 'hsl(var(--card))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="reviews" name="Code Reviews" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="mentoring" name="Mentoring (hrs)" fill="#14b8a6" radius={[4, 4, 0, 0]} />
                      <Bar dataKey="projects" name="Projects Led" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Recent Analysis */}
            {latestResult && (
              <div className="stat-card">
                <h3 className="text-lg font-semibold mb-4">Latest Analysis</h3>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="p-4 rounded-lg bg-accent">
                    <p className="text-sm text-muted-foreground mb-1">Collaboration Index</p>
                    <p className="text-2xl font-bold text-primary">{latestResult.metrics.collaborationIndex}%</p>
                  </div>
                  <div className="p-4 rounded-lg bg-accent">
                    <p className="text-sm text-muted-foreground mb-1">Growth Trend</p>
                    <p className="text-2xl font-bold text-primary">+{latestResult.metrics.growthTrend}%</p>
                  </div>
                  <div className="p-4 rounded-lg bg-accent">
                    <p className="text-sm text-muted-foreground mb-1">Fairness Score</p>
                    <p className="text-2xl font-bold text-primary">{latestResult.integrity.fairnessScore}%</p>
                  </div>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </div>
    </div>
  );
}

function StatCard({ 
  icon: Icon, 
  label, 
  value, 
  trend 
}: { 
  icon: typeof Users; 
  label: string; 
  value: string | number; 
  trend: string | null;
}) {
  return (
    <div className="stat-card">
      <div className="flex items-center justify-between mb-4">
        <div className="feature-icon">
          <Icon className="w-5 h-5" />
        </div>
        {trend && (
          <span className="badge-success">{trend}</span>
        )}
      </div>
      <p className="text-2xl font-bold text-foreground">{value}</p>
      <p className="text-sm text-muted-foreground">{label}</p>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-24">
      <div className="w-20 h-20 rounded-2xl bg-accent flex items-center justify-center mb-6">
        <FileText className="w-10 h-10 text-primary" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">No data available</h3>
      <p className="text-muted-foreground mb-6">Select a scenario and run analysis to see results</p>
      <div className="flex items-center gap-2 text-muted-foreground">
        <Layers className="w-4 h-4" />
        <span className="text-sm">Contribution as system impact</span>
      </div>
    </div>
  );
}
