import { useState } from 'react';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Layers, RefreshCw, Save, Settings as SettingsIcon } from 'lucide-react';
import { DashboardHeader } from '@/components/layout/DashboardHeader';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

export default function SettingsPage() {
  const { 
    apiBaseUrl, 
    setApiBaseUrl, 
    hideIndividualScores, 
    setHideIndividualScores,
    clearAnalysisData 
  } = useAppStore();
  
  const [localUrl, setLocalUrl] = useState(apiBaseUrl);

  const handleSaveUrl = () => {
    setApiBaseUrl(localUrl);
    toast.success('API URL saved successfully');
  };

  const handleClearData = () => {
    clearAnalysisData();
    toast.success('Analysis data cleared');
  };

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Dashboard" />
      
      <div className="p-6 max-w-3xl">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">Settings</h2>
          <p className="text-muted-foreground">Configure your ImpactLens experience.</p>
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="space-y-6"
        >
          {/* API Configuration */}
          <div className="stat-card">
            <div className="flex items-center gap-3 mb-4">
              <div className="feature-icon">
                <SettingsIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">API Configuration</h3>
                <p className="text-sm text-muted-foreground">Set the backend API base URL</p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <Label htmlFor="apiUrl">API Base URL</Label>
                <Input
                  id="apiUrl"
                  value={localUrl}
                  onChange={(e) => setLocalUrl(e.target.value)}
                  placeholder="http://127.0.0.1:8000"
                  className="mt-1.5"
                />
                <p className="text-xs text-muted-foreground mt-1.5">
                  Environment variable: <code className="text-primary">VITE_API_BASE_URL</code>
                </p>
              </div>
              <Button onClick={handleSaveUrl} className="gap-2">
                <Save className="w-4 h-4" />
                Save URL
              </Button>
            </div>
          </div>

          {/* Privacy Settings */}
          <div className="stat-card">
            <div className="flex items-center gap-3 mb-4">
              <div className="feature-icon">
                {hideIndividualScores ? (
                  <EyeOff className="w-5 h-5" />
                ) : (
                  <Eye className="w-5 h-5" />
                )}
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Privacy-First Mode</h3>
                <p className="text-sm text-muted-foreground">Control score visibility</p>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="hideScores" className="font-medium">Hide individual scores</Label>
                <p className="text-sm text-muted-foreground">Only show bands and roles on member cards</p>
              </div>
              <Switch
                id="hideScores"
                checked={hideIndividualScores}
                onCheckedChange={setHideIndividualScores}
              />
            </div>
          </div>

          {/* Data Management */}
          <div className="stat-card">
            <div className="flex items-center gap-3 mb-4">
              <div className="feature-icon">
                <RefreshCw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground">Data Management</h3>
                <p className="text-sm text-muted-foreground">Clear cached analysis data</p>
              </div>
            </div>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="gap-2">
                  <RefreshCw className="w-4 h-4" />
                  Clear Analysis Data
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Clear all data?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will remove all teams, members, and analysis results. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleClearData}>
                    Clear Data
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </motion.div>

        {/* Footer */}
        <div className="mt-12 pt-6 border-t border-border text-center">
          <p className="text-sm">
            <span className="font-semibold text-foreground">ImpactLens v2</span>
            <span className="text-muted-foreground"> — Contribution as system impact, not activity.</span>
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            A reflection tool for teams that value growth over surveillance.
          </p>
        </div>
      </div>
    </div>
  );
}
