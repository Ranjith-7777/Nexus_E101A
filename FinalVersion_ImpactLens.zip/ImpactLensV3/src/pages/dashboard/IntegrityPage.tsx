import { motion } from 'framer-motion';
import { AlertTriangle, CheckCircle, Shield, XCircle } from 'lucide-react';
import { DashboardHeader } from '@/components/layout/DashboardHeader';
import { useAppStore } from '@/lib/store';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

export default function IntegrityPage() {
  const { analysisResults } = useAppStore();
  const latestResult = analysisResults[0];

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Dashboard" />
      
      <div className="p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground">Integrity & Fairness</h2>
          <p className="text-muted-foreground">Built-in guardrails ensuring ethical evaluation</p>
        </div>

        {!latestResult ? (
          <EmptyState />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Overview Stats */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="stat-card">
                <div className="flex items-center gap-3 mb-4">
                  <div className="feature-icon">
                    <Shield className="w-5 h-5" />
                  </div>
                  <span className="text-sm text-muted-foreground">Fairness Score</span>
                </div>
                <p className="text-3xl font-bold text-primary">{latestResult.integrity.fairnessScore}%</p>
                <Progress value={latestResult.integrity.fairnessScore} className="h-2 mt-3" />
              </div>

              <div className="stat-card">
                <div className="flex items-center gap-3 mb-4">
                  <div className="feature-icon">
                    <CheckCircle className="w-5 h-5" />
                  </div>
                  <span className="text-sm text-muted-foreground">Bias Checks Passed</span>
                </div>
                <p className="text-3xl font-bold text-foreground">
                  {latestResult.integrity.biasChecks.filter(c => c.passed).length}
                  <span className="text-lg text-muted-foreground">/{latestResult.integrity.biasChecks.length}</span>
                </p>
              </div>

              <div className="stat-card">
                <div className="flex items-center gap-3 mb-4">
                  <div className="feature-icon">
                    <AlertTriangle className="w-5 h-5" />
                  </div>
                  <span className="text-sm text-muted-foreground">Transparency Level</span>
                </div>
                <p className="text-3xl font-bold text-foreground">{latestResult.integrity.transparencyLevel}</p>
              </div>
            </div>

            {/* Bias Checks */}
            <div className="stat-card">
              <h3 className="text-lg font-semibold text-foreground mb-6">Bias Detection Results</h3>
              <div className="space-y-4">
                {latestResult.integrity.biasChecks.map((check, index) => (
                  <motion.div
                    key={check.check}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    className={cn(
                      "p-4 rounded-lg border",
                      check.passed 
                        ? "bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-900"
                        : "bg-amber-50 border-amber-200 dark:bg-amber-950/20 dark:border-amber-900"
                    )}
                  >
                    <div className="flex items-start gap-3">
                      {check.passed ? (
                        <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                      ) : (
                        <XCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                      )}
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-foreground">{check.check}</h4>
                          <span className={cn(
                            "text-xs px-2 py-0.5 rounded-full",
                            check.passed ? "bg-green-100 text-green-800" : "bg-amber-100 text-amber-800"
                          )}>
                            {check.passed ? 'Passed' : 'Needs Attention'}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">{check.details}</p>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Ethical Guidelines */}
            <div className="stat-card">
              <h3 className="text-lg font-semibold text-foreground mb-4">Our Ethical Commitments</h3>
              <ul className="space-y-3">
                {[
                  'No ranked lists or "top performers" ever displayed',
                  'Individual scores are optional and always private to the user',
                  'Analysis considers role context and organizational structure',
                  'Regular bias audits with documented methodology',
                  'Full transparency on how every factor contributes to scores',
                ].map((item, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                    <span className="text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-24">
      <div className="w-20 h-20 rounded-2xl bg-accent flex items-center justify-center mb-6">
        <Shield className="w-10 h-10 text-primary" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">No integrity data</h3>
      <p className="text-muted-foreground">Run an analysis to see fairness and bias checks</p>
    </div>
  );
}
