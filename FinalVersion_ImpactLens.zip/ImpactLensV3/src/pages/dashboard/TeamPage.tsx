import { motion } from 'framer-motion';
import { Plus, Users } from 'lucide-react';
import { DashboardHeader } from '@/components/layout/DashboardHeader';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';

export default function TeamPage() {
  const { teams, currentTeamId, setCurrentTeam, addTeam, members } = useAppStore();
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamDesc, setNewTeamDesc] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleAddTeam = () => {
    if (newTeamName.trim()) {
      addTeam({ name: newTeamName, description: newTeamDesc });
      setNewTeamName('');
      setNewTeamDesc('');
      setDialogOpen(false);
    }
  };

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Dashboard" />
      
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Teams</h2>
            <p className="text-muted-foreground">Manage your organization's teams</p>
          </div>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Add Team
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Team</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div>
                  <Label htmlFor="teamName">Team Name</Label>
                  <Input
                    id="teamName"
                    value={newTeamName}
                    onChange={(e) => setNewTeamName(e.target.value)}
                    placeholder="e.g., Engineering Team"
                  />
                </div>
                <div>
                  <Label htmlFor="teamDesc">Description</Label>
                  <Input
                    id="teamDesc"
                    value={newTeamDesc}
                    onChange={(e) => setNewTeamDesc(e.target.value)}
                    placeholder="What does this team do?"
                  />
                </div>
                <Button onClick={handleAddTeam} className="w-full">
                  Create Team
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {teams.length === 0 ? (
          <EmptyState />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {teams.map((team) => {
              const teamMembers = members.length; // In real app, filter by team
              const isActive = currentTeamId === team.id;

              return (
                <motion.div
                  key={team.id}
                  whileHover={{ scale: 1.02 }}
                  className={`p-6 rounded-xl border cursor-pointer transition-all ${
                    isActive
                      ? 'bg-accent border-primary shadow-glow'
                      : 'bg-card border-border hover:border-primary/50'
                  }`}
                  onClick={() => setCurrentTeam(team.id)}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div className="feature-icon">
                      <Users className="w-5 h-5" />
                    </div>
                    {isActive && (
                      <span className="px-2 py-1 text-xs font-medium rounded-full bg-primary text-primary-foreground">
                        Active
                      </span>
                    )}
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-1">{team.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{team.description}</p>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="w-4 h-4" />
                    <span>{teamMembers} members</span>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-24">
      <div className="w-20 h-20 rounded-2xl bg-accent flex items-center justify-center mb-6">
        <Users className="w-10 h-10 text-primary" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">No teams yet</h3>
      <p className="text-muted-foreground">Create your first team or load demo data to get started</p>
    </div>
  );
}
