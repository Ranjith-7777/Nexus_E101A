import { motion } from 'framer-motion';
import { Plus, Trash2, UserCircle } from 'lucide-react';
import { DashboardHeader } from '@/components/layout/DashboardHeader';
import { useAppStore } from '@/lib/store';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const getBandColor = (band?: string) => {
  switch (band) {
    case 'High Impact': return 'badge-success';
    case 'Moderate Impact': return 'badge-info';
    case 'Growing': return 'badge-warning';
    default: return 'bg-muted text-muted-foreground';
  }
};

export default function MembersPage() {
  const { members, addMember, removeMember, hideIndividualScores } = useAppStore();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    role: '',
    department: '',
  });

  const handleAddMember = () => {
    if (formData.name.trim() && formData.email.trim()) {
      addMember({
        ...formData,
        band: 'Growing',
        impactScore: 50,
        contributions: { codeReviews: 0, mentoringHours: 0, projectsLed: 0, knowledgeSharing: 0 }
      });
      setFormData({ name: '', email: '', role: '', department: '' });
      setDialogOpen(false);
    }
  };

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Dashboard" />
      
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-foreground">Team Members</h2>
            <p className="text-muted-foreground">View and manage team members</p>
          </div>
          
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="w-4 h-4" />
                Add Member
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Team Member</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 pt-4">
                <div>
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData(f => ({ ...f, name: e.target.value }))}
                    placeholder="Full name"
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(f => ({ ...f, email: e.target.value }))}
                    placeholder="email@company.com"
                  />
                </div>
                <div>
                  <Label htmlFor="role">Role</Label>
                  <Input
                    id="role"
                    value={formData.role}
                    onChange={(e) => setFormData(f => ({ ...f, role: e.target.value }))}
                    placeholder="e.g., Senior Engineer"
                  />
                </div>
                <div>
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    value={formData.department}
                    onChange={(e) => setFormData(f => ({ ...f, department: e.target.value }))}
                    placeholder="e.g., Engineering"
                  />
                </div>
                <Button onClick={handleAddMember} className="w-full">
                  Add Member
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {members.length === 0 ? (
          <EmptyState />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid gap-4"
          >
            {members.map((member, index) => (
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="p-4 rounded-xl bg-card border border-border flex items-center gap-4"
              >
                {/* Avatar */}
                <div className="w-12 h-12 rounded-full bg-accent flex items-center justify-center">
                  <span className="text-lg font-semibold text-primary">
                    {member.name.split(' ').map(n => n[0]).join('')}
                  </span>
                </div>

                {/* Info */}
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold text-foreground">{member.name}</h3>
                    {member.band && (
                      <span className={`text-xs px-2 py-0.5 rounded-full ${getBandColor(member.band)}`}>
                        {member.band}
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{member.role} • {member.department}</p>
                </div>

                {/* Score */}
                {!hideIndividualScores && member.impactScore && (
                  <div className="text-right">
                    <p className="text-2xl font-bold text-primary">{member.impactScore}</p>
                    <p className="text-xs text-muted-foreground">Impact Score</p>
                  </div>
                )}

                {/* Actions */}
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent>
                    <AlertDialogHeader>
                      <AlertDialogTitle>Remove Member</AlertDialogTitle>
                      <AlertDialogDescription>
                        Are you sure you want to remove {member.name} from the team? This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => removeMember(member.id)}>
                        Remove
                      </AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-24">
      <div className="w-20 h-20 rounded-2xl bg-accent flex items-center justify-center mb-6">
        <UserCircle className="w-10 h-10 text-primary" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">No members yet</h3>
      <p className="text-muted-foreground">Add team members or load demo data to see the list</p>
    </div>
  );
}
