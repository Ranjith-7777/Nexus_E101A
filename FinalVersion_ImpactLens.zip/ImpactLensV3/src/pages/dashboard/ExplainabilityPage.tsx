import { motion } from 'framer-motion';
import { BookOpen, Info, Lightbulb, Scale } from 'lucide-react';
import { DashboardHeader } from '@/components/layout/DashboardHeader';
import { useAppStore } from '@/lib/store';
import { Progress } from '@/components/ui/progress';

export default function ExplainabilityPage() {
  const { analysisResults } = useAppStore();
  const latestResult = analysisResults[0];

  return (
    <div className="min-h-screen">
      <DashboardHeader title="Dashboard" />
      
      <div className="p-6">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground">Explainability</h2>
          <p className="text-muted-foreground">Understand how impact scores are calculated</p>
        </div>

        {!latestResult ? (
          <EmptyState />
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-6"
          >
            {/* Methodology */}
            <div className="stat-card">
              <div className="flex items-center gap-3 mb-4">
                <div className="feature-icon">
                  <BookOpen className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Methodology</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {latestResult.explainability.methodology}
              </p>
            </div>

            {/* Factors */}
            <div className="stat-card">
              <div className="flex items-center gap-3 mb-6">
                <div className="feature-icon">
                  <Scale className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Impact Factors</h3>
              </div>
              <div className="space-y-6">
                {latestResult.explainability.factors.map((factor, index) => (
                  <motion.div
                    key={factor.name}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-foreground">{factor.name}</span>
                      <span className="text-sm text-primary font-semibold">
                        {Math.round(factor.weight * 100)}%
                      </span>
                    </div>
                    <Progress value={factor.weight * 100} className="h-2 mb-2" />
                    <p className="text-sm text-muted-foreground">{factor.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Principles */}
            <div className="stat-card">
              <div className="flex items-center gap-3 mb-4">
                <div className="feature-icon">
                  <Info className="w-5 h-5" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Core Principles</h3>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-accent">
                  <h4 className="font-medium text-foreground mb-2">System Impact Over Activity</h4>
                  <p className="text-sm text-muted-foreground">
                    We measure how your work ripples through the organization, not just task completion.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-accent">
                  <h4 className="font-medium text-foreground mb-2">Growth, Not Ranking</h4>
                  <p className="text-sm text-muted-foreground">
                    Scores are for personal reflection, never for creating leaderboards or comparisons.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-accent">
                  <h4 className="font-medium text-foreground mb-2">Context Matters</h4>
                  <p className="text-sm text-muted-foreground">
                    Different roles have different impact patterns—we normalize across functions.
                  </p>
                </div>
                <div className="p-4 rounded-lg bg-accent">
                  <h4 className="font-medium text-foreground mb-2">Continuous Learning</h4>
                  <p className="text-sm text-muted-foreground">
                    The model adapts based on team feedback and organizational context changes.
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-24">
      <div className="w-20 h-20 rounded-2xl bg-accent flex items-center justify-center mb-6">
        <Lightbulb className="w-10 h-10 text-primary" />
      </div>
      <h3 className="text-xl font-semibold text-foreground mb-2">No analysis data</h3>
      <p className="text-muted-foreground">Run an analysis to see how impact scores are calculated</p>
    </div>
  );
}
