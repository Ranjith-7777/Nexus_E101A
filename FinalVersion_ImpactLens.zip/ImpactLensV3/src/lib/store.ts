import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  avatar?: string;
  impactScore?: number;
  band?: 'High Impact' | 'Moderate Impact' | 'Growing' | 'New';
  contributions?: {
    codeReviews: number;
    mentoringHours: number;
    projectsLed: number;
    knowledgeSharing: number;
  };
}

export interface AnalysisResult {
  id: string;
  runAt: string;
  scenario: string;
  teamId: string;
  members: TeamMember[];
  metrics: {
    avgImpactScore: number;
    teamHealth: number;
    collaborationIndex: number;
    growthTrend: number;
  };
  explainability: {
    factors: { name: string; weight: number; description: string }[];
    methodology: string;
  };
  integrity: {
    fairnessScore: number;
    biasChecks: { check: string; passed: boolean; details: string }[];
    transparencyLevel: 'High' | 'Medium' | 'Low';
  };
}

interface AppState {
  // Settings
  apiBaseUrl: string;
  hideIndividualScores: boolean;
  
  // Data
  teams: { id: string; name: string; description: string }[];
  currentTeamId: string | null;
  members: TeamMember[];
  analysisResults: AnalysisResult[];
  isAnalyzing: boolean;
  backendStatus: 'online' | 'offline';
  
  // Actions
  setApiBaseUrl: (url: string) => void;
  setHideIndividualScores: (hide: boolean) => void;
  setCurrentTeam: (teamId: string) => void;
  loadDemoData: () => void;
  runAnalysis: () => Promise<void>;
  clearAnalysisData: () => void;
  addMember: (member: Omit<TeamMember, 'id'>) => void;
  removeMember: (id: string) => void;
  addTeam: (team: { name: string; description: string }) => void;
}

const generateId = () => Math.random().toString(36).substr(2, 9);

const demoMembers: Omit<TeamMember, 'id'>[] = [
  {
    name: 'Sarah Chen',
    email: 'sarah.chen@company.com',
    role: 'Senior Engineer',
    department: 'Engineering',
    impactScore: 87,
    band: 'High Impact',
    contributions: { codeReviews: 45, mentoringHours: 20, projectsLed: 3, knowledgeSharing: 12 }
  },
  {
    name: 'Marcus Johnson',
    email: 'marcus.j@company.com',
    role: 'Tech Lead',
    department: 'Engineering',
    impactScore: 92,
    band: 'High Impact',
    contributions: { codeReviews: 67, mentoringHours: 35, projectsLed: 5, knowledgeSharing: 18 }
  },
  {
    name: 'Emily Rodriguez',
    email: 'emily.r@company.com',
    role: 'Product Designer',
    department: 'Design',
    impactScore: 78,
    band: 'Moderate Impact',
    contributions: { codeReviews: 0, mentoringHours: 15, projectsLed: 2, knowledgeSharing: 22 }
  },
  {
    name: 'David Kim',
    email: 'david.kim@company.com',
    role: 'Junior Developer',
    department: 'Engineering',
    impactScore: 65,
    band: 'Growing',
    contributions: { codeReviews: 12, mentoringHours: 5, projectsLed: 0, knowledgeSharing: 4 }
  },
  {
    name: 'Lisa Thompson',
    email: 'lisa.t@company.com',
    role: 'Engineering Manager',
    department: 'Engineering',
    impactScore: 95,
    band: 'High Impact',
    contributions: { codeReviews: 30, mentoringHours: 50, projectsLed: 8, knowledgeSharing: 25 }
  },
];

const demoTeams = [
  { id: 'team-1', name: 'Platform Team', description: 'Core infrastructure and platform services' },
  { id: 'team-2', name: 'Product Team', description: 'Customer-facing product development' },
];

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      apiBaseUrl: 'http://127.0.0.1:8000',
      hideIndividualScores: false,
      teams: [],
      currentTeamId: null,
      members: [],
      analysisResults: [],
      isAnalyzing: false,
      backendStatus: 'offline',

      setApiBaseUrl: (url) => set({ apiBaseUrl: url }),
      setHideIndividualScores: (hide) => set({ hideIndividualScores: hide }),
      setCurrentTeam: (teamId) => set({ currentTeamId: teamId }),

      loadDemoData: () => {
        const membersWithIds = demoMembers.map(m => ({ ...m, id: generateId() }));
        set({
          teams: demoTeams,
          currentTeamId: 'team-1',
          members: membersWithIds,
          backendStatus: 'online',
        });
      },

      runAnalysis: async () => {
        set({ isAnalyzing: true });
        
        // Simulate analysis delay
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const { members, currentTeamId } = get();
        
        if (members.length === 0) {
          set({ isAnalyzing: false });
          return;
        }

        const avgScore = members.reduce((acc, m) => acc + (m.impactScore || 0), 0) / members.length;
        
        const result: AnalysisResult = {
          id: generateId(),
          runAt: new Date().toISOString(),
          scenario: 'Standard Analysis',
          teamId: currentTeamId || 'unknown',
          members: members,
          metrics: {
            avgImpactScore: Math.round(avgScore),
            teamHealth: 85,
            collaborationIndex: 78,
            growthTrend: 12,
          },
          explainability: {
            methodology: 'Multi-factor weighted analysis combining quantitative metrics with peer feedback and organizational context.',
            factors: [
              { name: 'Code Contributions', weight: 0.25, description: 'Quality and quantity of code reviews, commits, and technical decisions' },
              { name: 'Mentorship', weight: 0.30, description: 'Time spent helping others grow, knowledge sharing sessions' },
              { name: 'Leadership', weight: 0.25, description: 'Projects led, cross-team collaboration, strategic initiatives' },
              { name: 'Knowledge Sharing', weight: 0.20, description: 'Documentation, presentations, and team enablement' },
            ],
          },
          integrity: {
            fairnessScore: 94,
            transparencyLevel: 'High',
            biasChecks: [
              { check: 'Gender Bias', passed: true, details: 'No significant correlation detected between gender and impact scores' },
              { check: 'Tenure Bias', passed: true, details: 'Scores normalized for experience level' },
              { check: 'Role Bias', passed: true, details: 'Cross-functional contributions weighted equally' },
              { check: 'Recency Bias', passed: false, details: 'Consider extending evaluation window for more balanced assessment' },
            ],
          },
        };

        set(state => ({
          analysisResults: [result, ...state.analysisResults],
          isAnalyzing: false,
          backendStatus: 'online',
        }));
      },

      clearAnalysisData: () => set({ analysisResults: [], members: [], teams: [], currentTeamId: null }),

      addMember: (member) => set(state => ({
        members: [...state.members, { ...member, id: generateId() }]
      })),

      removeMember: (id) => set(state => ({
        members: state.members.filter(m => m.id !== id)
      })),

      addTeam: (team) => set(state => ({
        teams: [...state.teams, { ...team, id: generateId() }]
      })),
    }),
    {
      name: 'impactlens-storage',
    }
  )
);
