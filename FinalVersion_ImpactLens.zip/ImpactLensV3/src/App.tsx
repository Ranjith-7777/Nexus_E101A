import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { lazy, Suspense } from "react";

// Lazy load pages to avoid router context issues during initialization
const LandingPage = lazy(() => import("./pages/LandingPage"));
const DashboardLayout = lazy(() => import("./components/layout/DashboardLayout").then(m => ({ default: m.DashboardLayout })));
const OverviewPage = lazy(() => import("./pages/dashboard/OverviewPage"));
const TeamPage = lazy(() => import("./pages/dashboard/TeamPage"));
const MembersPage = lazy(() => import("./pages/dashboard/MembersPage"));
const ExplainabilityPage = lazy(() => import("./pages/dashboard/ExplainabilityPage"));
const IntegrityPage = lazy(() => import("./pages/dashboard/IntegrityPage"));
const SettingsPage = lazy(() => import("./pages/dashboard/SettingsPage"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient();

// Loading fallback
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="animate-pulse text-primary">Loading...</div>
  </div>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/dashboard" element={<DashboardLayout />}>
              <Route index element={<OverviewPage />} />
              <Route path="team" element={<TeamPage />} />
              <Route path="members" element={<MembersPage />} />
              <Route path="explainability" element={<ExplainabilityPage />} />
              <Route path="integrity" element={<IntegrityPage />} />
              <Route path="settings" element={<SettingsPage />} />
            </Route>
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      </TooltipProvider>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;
