import { Sparkles, Play, WifiOff, Wifi } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/lib/store';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface DashboardHeaderProps {
  title: string;
}

export function DashboardHeader({ title }: DashboardHeaderProps) {
  const { loadDemoData, runAnalysis, isAnalyzing, backendStatus } = useAppStore();

  return (
    <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-sm border-b border-border">
      <div className="flex items-center justify-between px-6 py-4">
        <h1 className="text-xl font-semibold text-foreground">{title}</h1>
        
        <div className="flex items-center gap-3">
          {/* Status indicator */}
          <div className="flex items-center gap-2 text-sm">
            {backendStatus === 'online' ? (
              <>
                <Wifi className="w-4 h-4 text-success" />
                <span className="text-muted-foreground">Online</span>
              </>
            ) : (
              <>
                <WifiOff className="w-4 h-4 text-muted-foreground" />
                <span className="text-muted-foreground">Offline</span>
              </>
            )}
          </div>

          {/* Load Demo Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={loadDemoData}
            className="gap-2"
          >
            <Sparkles className="w-4 h-4" />
            Load Demo
          </Button>

          {/* Backend selector */}
          <Select defaultValue="offline">
            <SelectTrigger className="w-[140px]">
              <SelectValue placeholder="Backend" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="offline">Backend offline</SelectItem>
              <SelectItem value="local">Local API</SelectItem>
              <SelectItem value="cloud">Cloud API</SelectItem>
            </SelectContent>
          </Select>

          {/* Run Analysis Button */}
          <Button
            onClick={runAnalysis}
            disabled={isAnalyzing}
            className="gap-2 bg-primary hover:bg-primary/90"
          >
            <Play className="w-4 h-4" />
            {isAnalyzing ? 'Analyzing...' : 'Run Analysis'}
          </Button>
        </div>
      </div>
    </header>
  );
}
