import { Outlet } from 'react-router-dom';
import { DashboardSidebar } from './DashboardSidebar';

export function DashboardLayout() {
  return (
    <div className="min-h-screen bg-background">
      <DashboardSidebar />
      <main className="ml-56">
        <Outlet />
      </main>
    </div>
  );
}

export default DashboardLayout;
